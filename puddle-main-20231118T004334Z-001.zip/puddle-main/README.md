# Puddle | Django

Learn how to build a simple online market place website using Django.

This repository is a part of a video tutorial I created for FreeCodeCamp

My channel:
[CodeWithStein](https://www.youtube.com/channel/UCfVoYvY8BfTDeF63JQmQJvg/?sub_confirmation=1)

## Author
This repository and video is created by CodeWithStein. Check out my website for more information.

[Code With Stein - Website](https://codewithstein.com)
